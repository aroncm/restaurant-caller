#!/bin/bash

# Deploy Restaurant Caller to Railway
echo "🚀 Deploying Restaurant Caller to Railway..."

# Check if Railway CLI is installed
if ! command -v railway &> /dev/null; then
    echo "Installing Railway CLI..."
    npm install -g @railway/cli
fi

# Login to Railway
echo "🔐 Logging into Railway..."
railway login

# Initialize project
echo "📦 Initializing Railway project..."
railway init

# Deploy
echo "🚀 Deploying to Railway..."
railway up

echo "✅ Deployment complete!"
echo ""
echo "🔧 Next steps:"
echo "1. Go to Railway dashboard to get your app URL"
echo "2. Set environment variables in Railway:"
echo "   - TWILIO_ACCOUNT_SID=AC7978970a209aacd9d3ade9998e186235"
echo "   - TWILIO_AUTH_TOKEN=79a46d07a786c8adc587e28acb88948a"
echo "   - TWILIO_PHONE_NUMBER=+18662051399"
echo "   - OPENAI_API_KEY=sk-proj-ZYVnT3k1qhzOPFKWK_1r4iGnuY3bhP0yTWRVqDxbMn9zFrCKaDZwMGj0_p9ZNrJHbVuLrKK9wNT3BlbkFJM_4NhQdTdPRfRw2m5VKlGQ-bHe6y9w_B5nGKz6"
echo "   - CRAIG_PHONE=+17942375933" 
echo "   - NODE_ENV=production"
echo "3. Update Twilio webhooks to your Railway URL"