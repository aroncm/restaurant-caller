# Deploy Restaurant Caller Now

## Quick Railway Deployment

1. **Install Railway CLI:**
```bash
npm install -g @railway/cli
```

2. **Deploy from this directory:**
```bash
cd projects/restaurant-caller
railway login
railway init
railway up
```

3. **Set Environment Variables in Railway Dashboard:**
```
TWILIO_ACCOUNT_SID=AC7978970a209aacd9d3ade9998e186235
TWILIO_AUTH_TOKEN=79a46d07a786c8adc587e28acb88948a
TWILIO_PHONE_NUMBER=+18662051399
OPENAI_API_KEY=sk-proj-ZYVnT3k1qhzOPFKWK_1r4iGnuY3bhP0yTWRVqDxbMn9zFrCKaDZwMGj0_p9ZNrJHbVuLrKK9wNT3BlbkFJM_4NhQdTdPRfRw2m5VKlGQ-bHe6y9w_B5nGKz6
CRAIG_PHONE=+17942375933
NODE_ENV=production
```

4. **Get your deployment URL** (Railway will show it)

5. **Update Twilio Webhooks:**
   - Go to Twilio Console > Phone Numbers > Your Number
   - Set Voice webhook: `https://your-railway-app.railway.app/voice-handler`
   - Set Status callback: `https://your-railway-app.railway.app/call-status`

## Alternative: Manual Upload to Render

1. Create GitHub repo with this code
2. Connect to Render.com
3. Set environment variables
4. Deploy

## Test Once Live

```bash
curl -X POST https://your-app-url.com/health
```

Then make a test reservation call!

## Cost: ~$5/month + usage

- Railway hosting: ~$5/month
- Calls: $0.09 each
- Twilio phone: $1/month

**Ready to save time making reservations!**