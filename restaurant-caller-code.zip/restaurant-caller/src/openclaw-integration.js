const axios = require('axios');

class OpenClawIntegration {
  constructor() {
    this.gatewayUrl = process.env.OPENCLAW_GATEWAY_URL || 'http://localhost:3000';
    this.token = process.env.OPENCLAW_TOKEN;
  }

  // Send message via OpenClaw messaging system
  async sendMessage(message, channel = 'telegram', target = process.env.CRAIG_PHONE) {
    try {
      const response = await axios.post(`${this.gatewayUrl}/api/message`, {
        action: 'send',
        channel: channel,
        target: target,
        message: message
      }, {
        headers: this.token ? { 'Authorization': `Bearer ${this.token}` } : {},
        timeout: 10000
      });

      return response.data;
    } catch (error) {
      console.error('Error sending message via OpenClaw:', error.message);
      throw error;
    }
  }

  // Create a reservation task in OpenClaw
  async createReservationTask(restaurantName, date, time, partySize, specialRequests) {
    const taskMessage = `📞 RESTAURANT RESERVATION REQUEST

Restaurant: ${restaurantName}
Date: ${date}
Time: ${time}
Party Size: ${partySize}
Special Requests: ${specialRequests}

Use the restaurant caller service to make this reservation automatically.`;

    await this.sendMessage(taskMessage);
  }

  // Notify about reservation result
  async notifyReservationResult(callContext, reservationDetails) {
    let message;
    
    if (reservationDetails.confirmed) {
      message = `✅ **RESERVATION CONFIRMED**

🏪 Restaurant: ${callContext.restaurant_name}
📅 Date: ${reservationDetails.date}
🕒 Time: ${reservationDetails.time}
👥 Party Size: ${reservationDetails.party_size}
🎫 Confirmation: ${reservationDetails.confirmation_number || 'N/A'}
📝 Notes: ${reservationDetails.notes}

📞 Call recording and transcript available if needed.`;
    } else {
      message = `❌ **RESERVATION FAILED**

🏪 Restaurant: ${callContext.restaurant_name}
📅 Requested: ${callContext.date} at ${callContext.time}
👥 Party Size: ${callContext.party_size}

❗ Issue: ${reservationDetails.notes}

💡 Suggestions:
- Try different date/time
- Call manually for complex requests  
- Consider alternative restaurants`;
    }

    await this.sendMessage(message);
  }

  // Log reservation attempt
  async logReservationAttempt(callContext, outcome) {
    const logMessage = `📊 RESERVATION LOG

Restaurant: ${callContext.restaurant_name}
Phone: ${callContext.restaurant_phone}
Requested: ${callContext.date} at ${callContext.time} for ${callContext.party_size}
Outcome: ${outcome}
Timestamp: ${new Date().toISOString()}`;

    console.log(logMessage);
    
    // Optionally send to a logging channel
    // await this.sendMessage(logMessage, 'telegram', 'logging_channel');
  }

  // Get Craig's availability from calendar (future integration)
  async getAvailability(date) {
    // Placeholder for calendar integration
    // Could integrate with Google Calendar API via OpenClaw
    return {
      available: true,
      conflicts: []
    };
  }

  // Add restaurant to favorites/database
  async saveRestaurant(restaurantInfo) {
    const message = `📝 RESTAURANT SAVED

Name: ${restaurantInfo.name}
Phone: ${restaurantInfo.phone}
Cuisine: ${restaurantInfo.cuisine}
Notes: ${restaurantInfo.notes}

Added to restaurant database for future reservations.`;

    await this.sendMessage(message);
  }
}

module.exports = OpenClawIntegration;