// Restaurant database - Long Island area restaurants
const restaurants = {
  "long_island": [
    {
      name: "Mirabelle Restaurant & Tavern",
      phone: "+15163331515",
      location: "Stony Brook, NY",
      cuisine: "French",
      price_range: "$$$",
      notes: "Upscale French, reservations recommended",
      hours: "Tue-Sun 5:30-9:30pm"
    },
    {
      name: "Peter Luger Steak House",
      phone: "+15162398555", 
      location: "Great Neck, NY",
      cuisine: "Steakhouse",
      price_range: "$$$$",
      notes: "Cash only, no reservations for parties under 5",
      hours: "Mon-Sat 11:30am-9:45pm, Sun 1-9pm"
    },
    {
      name: "Blackstone Steakhouse",
      phone: "+15167417300",
      location: "Melville, NY", 
      cuisine: "Steakhouse",
      price_range: "$$$",
      notes: "Modern steakhouse, reservations accepted",
      hours: "Mon-Thu 5-10pm, Fri-Sat 5-11pm, Sun 4-9pm"
    },
    {
      name: "Butera's Restaurant",
      phone: "+15163641700",
      location: "Woodbury, NY",
      cuisine: "Italian",
      price_range: "$$",
      notes: "Traditional Italian, family-owned",
      hours: "Daily 5-10pm"
    },
    {
      name: "Coach Grill",
      phone: "+15163671500", 
      location: "Oyster Bay, NY",
      cuisine: "American",
      price_range: "$$$",
      notes: "Historic tavern atmosphere",
      hours: "Mon-Thu 5-9pm, Fri-Sat 5-10pm, Sun 4-8pm"
    },
    {
      name: "Café Testarossa",
      phone: "+15166920700",
      location: "Syosset, NY",
      cuisine: "Italian",
      price_range: "$$",
      notes: "Local favorite, casual Italian",
      hours: "Daily 5-10pm"
    }
  ]
};

// Find restaurants by name, cuisine, or location
function findRestaurants(query) {
  const results = [];
  
  for (const region in restaurants) {
    restaurants[region].forEach(restaurant => {
      const searchText = `${restaurant.name} ${restaurant.cuisine} ${restaurant.location}`.toLowerCase();
      if (searchText.includes(query.toLowerCase())) {
        results.push(restaurant);
      }
    });
  }
  
  return results;
}

// Get restaurant by exact name
function getRestaurant(name) {
  for (const region in restaurants) {
    const restaurant = restaurants[region].find(r => 
      r.name.toLowerCase() === name.toLowerCase()
    );
    if (restaurant) return restaurant;
  }
  return null;
}

// Get nearby restaurants (simplified - by region)
function getNearbyRestaurants(location = "long_island", cuisine = null, priceRange = null) {
  let results = restaurants[location] || restaurants.long_island;
  
  if (cuisine) {
    results = results.filter(r => 
      r.cuisine.toLowerCase().includes(cuisine.toLowerCase())
    );
  }
  
  if (priceRange) {
    results = results.filter(r => r.price_range === priceRange);
  }
  
  return results;
}

module.exports = {
  restaurants,
  findRestaurants,
  getRestaurant,
  getNearbyRestaurants
};