const express = require('express');
const twilio = require('twilio');
const OpenAI = require('openai');
const axios = require('axios');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3001;

// Initialize services
const twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Store active calls
const activeCalls = new Map();

// Restaurant reservation caller endpoint
app.post('/make-reservation', async (req, res) => {
  try {
    const { 
      restaurant_name, 
      restaurant_phone, 
      date, 
      time, 
      party_size, 
      special_requests = '' 
    } = req.body;

    console.log(`Starting reservation call for ${restaurant_name}`);

    // Generate call context
    const callContext = {
      restaurant_name,
      date,
      time,
      party_size,
      special_requests,
      caller_name: "Craig Aron",
      caller_phone: process.env.CRAIG_PHONE,
      conversation_state: "greeting",
      call_start: new Date().toISOString()
    };

    // Initiate Twilio call
    const call = await twilioClient.calls.create({
      to: restaurant_phone,
      from: process.env.TWILIO_PHONE_NUMBER,
      url: `${req.protocol}://${req.get('host')}/voice-handler`,
      statusCallback: `${req.protocol}://${req.get('host')}/call-status`,
      statusCallbackEvent: ['initiated', 'ringing', 'answered', 'completed'],
      record: true,
      recordingStatusCallback: `${req.protocol}://${req.get('host')}/recording-status`
    });

    // Store call context
    activeCalls.set(call.sid, callContext);

    res.json({
      success: true,
      call_id: call.sid,
      message: `Calling ${restaurant_name} for reservation on ${date} at ${time} for ${party_size} people`
    });

  } catch (error) {
    console.error('Error making reservation call:', error);
    res.status(500).json({ error: 'Failed to initiate call' });
  }
});

// Twilio voice webhook handler
app.post('/voice-handler', async (req, res) => {
  const callSid = req.body.CallSid;
  const callContext = activeCalls.get(callSid);

  if (!callContext) {
    console.error(`No context found for call ${callSid}`);
    return res.status(400).send('No call context found');
  }

  console.log(`Voice handler called for ${callContext.restaurant_name}`);

  // Generate TwiML response
  const twiml = new twilio.twiml.VoiceResponse();

  // Initial greeting
  if (callContext.conversation_state === 'greeting') {
    const greeting = await generateGreeting(callContext);
    
    twiml.say({
      voice: 'alice',
      language: 'en-US'
    }, greeting);

    // Start gathering speech input
    const gather = twiml.gather({
      input: 'speech',
      timeout: 10,
      speechTimeout: 'auto',
      action: '/handle-response',
      method: 'POST'
    });

    // Update conversation state
    callContext.conversation_state = 'awaiting_response';
    activeCalls.set(callSid, callContext);
  }

  res.type('text/xml');
  res.send(twiml.toString());
});

// Handle speech responses
app.post('/handle-response', async (req, res) => {
  const callSid = req.body.CallSid;
  const speechResult = req.body.SpeechResult;
  const callContext = activeCalls.get(callSid);

  console.log(`Response from ${callContext?.restaurant_name}: "${speechResult}"`);

  const twiml = new twilio.twiml.VoiceResponse();

  try {
    // Process the restaurant's response with AI
    const aiResponse = await processRestaurantResponse(speechResult, callContext);
    
    if (aiResponse.action === 'respond') {
      // Generate and speak AI response
      twiml.say({
        voice: 'alice',
        language: 'en-US'
      }, aiResponse.message);

      // Continue gathering if conversation isn't complete
      if (!aiResponse.complete) {
        const gather = twiml.gather({
          input: 'speech',
          timeout: 10,
          speechTimeout: 'auto',
          action: '/handle-response',
          method: 'POST'
        });
      } else {
        // End call and notify Craig
        twiml.say('Thank you, goodbye.');
        await notifyCraig(callContext, aiResponse.reservation_details);
      }
    } else if (aiResponse.action === 'hangup') {
      twiml.say('Thank you for your time. Goodbye.');
      await notifyCraig(callContext, aiResponse.reservation_details);
    }

  } catch (error) {
    console.error('Error processing response:', error);
    twiml.say('I apologize, let me call you back shortly. Goodbye.');
  }

  res.type('text/xml');
  res.send(twiml.toString());
});

// Generate initial greeting using AI
async function generateGreeting(callContext) {
  const prompt = `You are calling ${callContext.restaurant_name} to make a reservation for Craig Aron. 
  Details:
  - Date: ${callContext.date}
  - Time: ${callContext.time}
  - Party size: ${callContext.party_size}
  - Special requests: ${callContext.special_requests}
  
  Generate a polite, professional greeting to start the conversation. Keep it natural and brief.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 150,
      temperature: 0.7
    });

    return response.choices[0].message.content.trim();
  } catch (error) {
    console.error('Error generating greeting:', error);
    return `Hello, I'd like to make a reservation for ${callContext.date} at ${callContext.time} for ${callContext.party_size} people under the name Craig Aron.`;
  }
}

// Process restaurant responses with AI
async function processRestaurantResponse(speechResult, callContext) {
  const prompt = `You are an AI assistant making a restaurant reservation call. 
  
  Context:
  - Restaurant: ${callContext.restaurant_name}
  - Requested: ${callContext.date} at ${callContext.time} for ${callContext.party_size} people
  - Special requests: ${callContext.special_requests}
  
  Restaurant staff said: "${speechResult}"
  
  Analyze their response and provide:
  1. What action to take (respond/hangup)
  2. Your response message (if responding)
  3. Whether the conversation is complete
  4. Any reservation details confirmed
  
  Respond in JSON format:
  {
    "action": "respond|hangup",
    "message": "your response to restaurant staff",
    "complete": false,
    "reservation_details": {
      "confirmed": false,
      "date": "",
      "time": "",
      "party_size": "",
      "confirmation_number": "",
      "notes": ""
    }
  }`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 300,
      temperature: 0.3
    });

    return JSON.parse(response.choices[0].message.content.trim());
  } catch (error) {
    console.error('Error processing response:', error);
    return {
      action: "hangup",
      message: "Thank you for your time.",
      complete: true,
      reservation_details: { confirmed: false, notes: "Error processing response" }
    };
  }
}

// Notify Craig of reservation results
async function notifyCraig(callContext, reservationDetails) {
  const message = reservationDetails.confirmed 
    ? `✅ Reservation confirmed at ${callContext.restaurant_name}!\n\nDetails:\n- Date: ${reservationDetails.date}\n- Time: ${reservationDetails.time}\n- Party: ${reservationDetails.party_size}\n- Confirmation: ${reservationDetails.confirmation_number}\n- Notes: ${reservationDetails.notes}`
    : `❌ Could not secure reservation at ${callContext.restaurant_name}\n\nDetails: ${reservationDetails.notes}`;

  console.log('Notifying Craig:', message);

  // Send via OpenClaw messaging
  try {
    await axios.post(`${process.env.OPENCLAW_GATEWAY_URL}/api/message`, {
      action: 'send',
      channel: 'telegram',
      target: process.env.CRAIG_PHONE,
      message: message
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.OPENCLAW_TOKEN}`
      }
    });
  } catch (error) {
    console.error('Error notifying Craig:', error);
  }
}

// Call status webhook
app.post('/call-status', (req, res) => {
  const { CallSid, CallStatus } = req.body;
  console.log(`Call ${CallSid} status: ${CallStatus}`);
  
  if (CallStatus === 'completed' || CallStatus === 'failed') {
    activeCalls.delete(CallSid);
  }
  
  res.sendStatus(200);
});

// Recording status webhook
app.post('/recording-status', (req, res) => {
  const { CallSid, RecordingUrl } = req.body;
  console.log(`Recording available for call ${CallSid}: ${RecordingUrl}`);
  res.sendStatus(200);
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

app.listen(port, () => {
  console.log(`Restaurant caller service running on port ${port}`);
});

module.exports = app;