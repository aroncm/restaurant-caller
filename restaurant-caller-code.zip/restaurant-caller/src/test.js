// Test the restaurant caller system
const axios = require('axios');
require('dotenv').config();

const API_BASE = 'http://localhost:3001';

async function testReservationCall() {
  try {
    console.log('🧪 Testing restaurant reservation call...');

    const reservationRequest = {
      restaurant_name: "Café Testarossa", 
      restaurant_phone: "+15166920700", // This would be a test number in production
      date: "February 25th, 2026",
      time: "7:00 PM",
      party_size: "4",
      special_requests: "Prefer quiet table, celebrating anniversary"
    };

    console.log('Making reservation request:', reservationRequest);

    const response = await axios.post(`${API_BASE}/make-reservation`, reservationRequest);
    
    console.log('✅ Test call initiated successfully:');
    console.log('Call ID:', response.data.call_id);
    console.log('Message:', response.data.message);

    // Monitor the call for a few seconds
    console.log('\n⏳ Call in progress... Check logs for conversation flow');
    
  } catch (error) {
    console.error('❌ Test failed:', error.message);
    if (error.response) {
      console.error('Response:', error.response.data);
    }
  }
}

async function testHealthCheck() {
  try {
    console.log('\n🏥 Testing health check...');
    const response = await axios.get(`${API_BASE}/health`);
    console.log('✅ Service healthy:', response.data);
  } catch (error) {
    console.error('❌ Health check failed:', error.message);
  }
}

async function testRestaurantSearch() {
  console.log('\n🔍 Testing restaurant search...');
  const { findRestaurants, getNearbyRestaurants } = require('./restaurants');
  
  console.log('Italian restaurants:', findRestaurants('italian').map(r => r.name));
  console.log('Syosset restaurants:', findRestaurants('syosset').map(r => r.name));
  console.log('$$$ restaurants:', getNearbyRestaurants('long_island', null, '$$$').map(r => r.name));
}

// Run tests
async function runTests() {
  console.log('🚀 Starting Restaurant Caller Tests\n');
  
  await testHealthCheck();
  await testRestaurantSearch();
  
  // Uncomment to test actual calls (requires Twilio setup)
  // await testReservationCall();
  
  console.log('\n✅ All tests completed!');
}

if (require.main === module) {
  runTests().catch(console.error);
}

module.exports = {
  testReservationCall,
  testHealthCheck,
  testRestaurantSearch
};