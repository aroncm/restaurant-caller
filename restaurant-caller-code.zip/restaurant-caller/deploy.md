# Restaurant Caller Deployment Guide

## Quick Deploy Options

### Option 1: Railway (Recommended)
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login and deploy
railway login
railway init
railway add
railway deploy

# Set environment variables in Railway dashboard
```

### Option 2: Render
```bash
# Connect GitHub repo to Render
# Set build command: npm install
# Set start command: npm start
# Configure environment variables
```

### Option 3: DigitalOcean App Platform
```bash
# Create app from GitHub repo
# Configure build/run commands
# Set environment variables
```

## Environment Variables to Set

```bash
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=your_auth_token_here
TWILIO_PHONE_NUMBER=+1234567890
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
OPENCLAW_GATEWAY_URL=https://your-openclaw-domain.com
OPENCLAW_TOKEN=your_gateway_token
CRAIG_PHONE=+17942375933
NODE_ENV=production
```

## Twilio Configuration

1. **Buy phone number** ($1/month)
2. **Configure webhooks** in Twilio Console:
   - Voice URL: `https://your-app.com/voice-handler`
   - Status callback: `https://your-app.com/call-status`
   - Recording callback: `https://your-app.com/recording-status`

## Production Checklist

- [ ] Environment variables configured
- [ ] Twilio webhooks pointing to production URL
- [ ] Health check endpoint responding
- [ ] Test call successful
- [ ] OpenClaw integration working
- [ ] Monitoring/logging configured

## Monitoring

Add to your monitoring stack:
- Health check: `GET /health`
- Call success rates
- Response time metrics
- Error logging

## Cost Management

Expected monthly costs:
- **Twilio phone number**: $1.00
- **Hosting**: $5-10 (Railway/Render)
- **Usage**: $0.09 × calls made
- **Total**: ~$6-12/month base + usage

## Security

- Never commit `.env` file
- Use secure webhook URLs (HTTPS)
- Rotate API keys periodically
- Monitor unusual call patterns